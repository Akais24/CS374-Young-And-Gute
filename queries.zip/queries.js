var queries = [
    { "question": "Q. What is the question This question is long, it should be two-line question?",
        "choices": ["choice1", "choice2", "choice3", "choide4", "choice5"]}
]